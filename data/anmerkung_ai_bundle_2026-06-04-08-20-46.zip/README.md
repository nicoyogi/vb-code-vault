# Anmerkung Rule-Update Bundle

Engine version: **v1.13.0**  
Exported: 2026-06-04T08:20:46.028Z  
Records: **46** training case(s)
Source file: `assets/anmerkung.js`

## Files in this bundle

- `training.jsonl` — one JSON record per line, one record per failing/correct row from Diff Mode.
- `rule_spec.json` — the schema. Lists every PHRASES key, every threshold, every input field per forwarder, and the exact source-code symbol an AI should edit to update rules.
- `README.md` — this file.

## How an AI assistant should use this bundle

### 1. Read `rule_spec.json` first
It tells you:
- The exact source file (`assets/anmerkung.js`) and the four processor symbols to edit (`processDachser`, `processKN`, `processDHL`, `processWackler`).
- The `PHRASES` catalog: every key you can emit and the German string it produces.
- The threshold per forwarder for the `hasErr()` numeric guard.
- The English glossary for every input field on every forwarder.
- The exact label / granular_label taxonomy.

### 2. Walk `training.jsonl`
Each line is a JSON object with these fields (selected):

| field | meaning |
| --- | --- |
| `forwarder` | one of `dachser` / `kn` / `dhl` / `wackler` |
| `processor` | exact JS symbol to edit, e.g. `processWackler` |
| `applicable_threshold` | the `hasErr()` tolerance for this forwarder |
| `label` | `wrong` / `missed` / `overfired` / `correct` |
| `granular_label` | `phrase_subset` / `phrase_superset` / `phrase_disjoint` / etc. |
| `expected_phrase_keys` | PHRASES keys ground truth wants — use `rule_spec.phrases[key]` to see the German string |
| `predicted_phrase_keys` | PHRASES keys the engine output |
| `missing_phrase_keys` | in expected, NOT in predicted → engine UNDER-fired |
| `extra_phrase_keys` | in predicted, NOT in expected → engine OVER-fired |
| `engine_phrase_keys` | what `process<Forwarder>` would output today (drift detector) |
| `inputs` | per-row map of cell values the rules read; keys explained in `rule_spec.forwarders.<fw>.input_glossary` |
| `reason` | trigger trace (raw cell values that fired branches) |
| `row_uid` | stable hash for joining across runs |
| `source_file` | which predicted/expected file pair this row came from (set when exported from Bulk Diff; blank for a single-pair run) |

Synthetic key prefixes:
- `lit_*` — phrase string is hard-coded inside a processor (not yet in `PHRASES`). Promote it to `PHRASES` if you need to fire it from a new branch.
- `tpl_*` — dynamic phrase that interpolates runtime values (see `rule_spec.phrase_templates`).
- `?:<raw>` — phrase did not resolve. Add it to `PHRASES` or `PHRASE_LITERALS` first.

### 3. Apply the rule-update workflow

- 1. Group records by forwarder, then by missing_phrase_keys / extra_phrase_keys patterns.
- 2. For missed rows: locate the existing branch that emits the missing key (or add one). Loosen its gate using the inputs.* signals on the failing rows.
- 3. For overfired rows: locate the branch that emits the extra key. Tighten its gate so the inputs.* signature on these rows no longer matches.
- 4. For wrong rows: handle the missing and extra key sets independently.
- 5. Preserve the join() pattern — phrases are de-duplicated case-insensitively automatically.
- 6. After editing, the user re-runs Train & Compare; engine_drift turns into "correct" when fixed.

### 4. Common patterns

**`missed`** — engine should have emitted a phrase but didn't.
- Find the existing branch in `process<Forwarder>` that emits the `missing_phrase_keys[i]` (search for `P.<key>` or the literal phrase).
- Diagnose why the gate didn't match: compare the failing row's `inputs` against the gate condition.
- Loosen the gate or add a parallel branch using `inputs` as new gating signals.

**`overfired`** — engine emitted a phrase that shouldn't appear.
- Find the branch that emits the `extra_phrase_keys[i]`.
- Add a guard using `inputs` so the branch no longer matches the row's signature.
- Be careful not to break `correct` rows for the same forwarder — re-run Diff Mode to verify.

**`wrong`** — both missed AND extra keys present.
- Treat the missing and extra sets independently. Often a single branch picked the wrong phrase: change the phrase emitted, not the gate.

### 5. Verify
Re-run Diff Mode → Train & Compare. The chip counts should move from `wrong`/`missed`/`overfired` toward `correct`. `engine drift` rows turn into `correct` once the rule emits what slot A says.
