# Anmerkung Rule-Update Bundle

Engine version: **v1.24.0**  
Exported: 2026-06-12T04:04:18.823Z  
Records: **9** training case(s)
Source file: `assets/anmerkung.js`

## Files in this bundle

- `prompt.md` — ready-to-paste prompt. Attach the other files to your AI assistant and paste this; it encodes the whole workflow below.
- `summary.json` — failure patterns, pre-grouped: every (forwarder × engine_missing/extra_phrase_keys) combination with its row count, label distribution, example `row_uid`s, and the input cells shared by every failing row (gate-signal candidates). Records are sorted deterministically (forwarder → source pair → sheet → row) so bundles diff cleanly across runs.
- `training.jsonl` — one JSON record per line, one record per failing/correct row from Diff Mode.
- `rule_spec.json` — the schema. Lists every PHRASES key, every threshold, every input field per forwarder, and the exact source-code symbol an AI should edit to update rules.
- `README.md` — this file.

## How an AI assistant should use this bundle

### 0. Start with `summary.json`
It already does workflow step 1 (grouping) for you: patterns are sorted by row count, each carries `suggested_action` (`add_or_loosen_branch` / `guard_or_tighten_branch` / `fix_both`), `shared_inputs` (cell values identical on every failing row — prime gate signals), `varying_inputs` (present everywhere but differing — must NOT become gate conditions), and `example_row_uids` to pull the full records from `training.jsonl`. Rows the engine already solves are counted in `engine_solved` and excluded from patterns — they are the regression set a fix must not break.

### 1. Read `rule_spec.json`
It tells you:
- The exact source file (`assets/anmerkung.js`) and the four processor symbols to edit (`processDachser`, `processKN`, `processDHL`, `processWackler`).
- The `PHRASES` catalog: every key you can emit and the German string it produces.
- The threshold per forwarder for the `hasErr()` numeric guard.
- The English glossary for every input field on every forwarder.
- The exact label / granular_label taxonomy.

### 2. Walk `training.jsonl`
Each line is a JSON object with these fields (selected):

| field | meaning |
| --- | --- |
| `forwarder` | one of `dachser` / `kn` / `dhl` / `wackler` |
| `processor` | exact JS symbol to edit, e.g. `processWackler` |
| `applicable_threshold` | the `hasErr()` tolerance for this forwarder |
| `label` | `wrong` / `missed` / `overfired` / `correct` |
| `granular_label` | `phrase_subset` / `phrase_superset` / `phrase_disjoint` / etc. |
| `expected_phrase_keys` | PHRASES keys ground truth wants — use `rule_spec.phrases[key]` to see the German string |
| `predicted_phrase_keys` | PHRASES keys the engine output |
| `missing_phrase_keys` | in expected, NOT in predicted → engine UNDER-fired |
| `extra_phrase_keys` | in predicted, NOT in expected → engine OVER-fired |
| `engine_phrase_keys` | what `process<Forwarder>` would output today (drift detector) |
| `engine_label` | how the CURRENT engine scores against ground truth B (`correct`/`wrong`/`missed`/`overfired`) — **the authoritative fix target** |
| `engine_matches_b` | `true` once the current engine matches truth; the goal is to flip this to `true` |
| `engine_missing_phrase_keys` | in truth, NOT in the current engine output → branch to **add / loosen** |
| `engine_extra_phrase_keys` | in the current engine output, NOT in truth → branch to **guard / tighten** |
| `engine_vs_expected_jaccard` | phrase-set similarity of current engine output vs truth (1.0 = solved) |
| `inputs` | per-row map of cell values the rules read; keys explained in `rule_spec.forwarders.<fw>.input_glossary` |
| `reason` | trigger trace (raw cell values that fired branches) |
| `row_uid` | stable hash for joining across runs |
| `source_file` | which predicted/expected file pair this row came from (set when exported from Bulk Diff; blank for a single-pair run) |

> **Use the `engine_*` fields, not the plain `predicted`/`missing`/`extra` fields, to drive rule edits.** The plain fields compare slot A (your tool output, which may be stale or from another tool) against truth B; the `engine_*` fields compare what `process<Forwarder>` emits *today* against truth B. When `label == "correct"` but `engine_label != "correct"`, the tool was right but the current engine regressed on that row — fix it.

Synthetic key prefixes:
- `lit_*` — phrase string is hard-coded inside a processor (not yet in `PHRASES`). Promote it to `PHRASES` if you need to fire it from a new branch.
- `tpl_*` — dynamic phrase that interpolates runtime values (see `rule_spec.phrase_templates`).
- `?:<raw>` — phrase did not resolve. Add it to `PHRASES` or `PHRASE_LITERALS` first.

### 3. Apply the rule-update workflow

- 1. Group records by forwarder, then by engine_missing_phrase_keys / engine_extra_phrase_keys patterns (fall back to missing_/extra_phrase_keys when engine_label is blank, e.g. unknown forwarder).
- 2. For engine_missing (engine UNDER-fired vs truth): locate the existing branch that emits the missing key (or add one). Loosen its gate using the inputs.* signals on the failing rows.
- 3. For engine_extra (engine OVER-fired vs truth): locate the branch that emits the extra key. Tighten its gate so the inputs.* signature on these rows no longer matches.
- 4. For rows that are both: handle the missing and extra key sets independently.
- 5. Preserve the join() pattern — phrases are de-duplicated case-insensitively automatically.
- 6. After editing, the user re-runs Train & Compare; engine_matches_b flips to true and the row drops out of the wrong/missed/overfired (and engine-drift) buckets.

### 4. Common patterns

**`missed`** — engine should have emitted a phrase but didn't.
- Find the existing branch in `process<Forwarder>` that emits the `missing_phrase_keys[i]` (search for `P.<key>` or the literal phrase).
- Diagnose why the gate didn't match: compare the failing row's `inputs` against the gate condition.
- Loosen the gate or add a parallel branch using `inputs` as new gating signals.

**`overfired`** — engine emitted a phrase that shouldn't appear.
- Find the branch that emits the `extra_phrase_keys[i]`.
- Add a guard using `inputs` so the branch no longer matches the row's signature.
- Be careful not to break `correct` rows for the same forwarder — re-run Diff Mode to verify.

**`wrong`** — both missed AND extra keys present.
- Treat the missing and extra sets independently. Often a single branch picked the wrong phrase: change the phrase emitted, not the gate.

### 5. Verify
Re-run Diff Mode → Train & Compare. Each fixed row's `engine_matches_b` flips to `true`, its `engine_missing_phrase_keys` / `engine_extra_phrase_keys` empty out, and the `engine drift` overlay clears. Watch the chip counts move from `wrong`/`missed`/`overfired` toward `correct`.
