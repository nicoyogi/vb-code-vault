# Prompt — paste into your AI assistant together with this bundle's files

> Attach `training.jsonl`, `rule_spec.json`, and `summary.json` (and `assets/anmerkung.js` if the assistant cannot read the repository), then paste everything below the line.

---

You are maintaining `assets/anmerkung.js` (engine v1.23.0), a deterministic, browser-side rule engine that fills the German "Anmerkung" column of forwarder invoice audits. I am giving you labeled training data from the engine's Diff Mode:

- `summary.json` — failure patterns, pre-grouped by forwarder and by the phrase keys the CURRENT engine gets wrong vs ground truth. 5 pattern(s) over 7 actionable row(s); 0 row(s) the engine already solves. Top patterns:
  - dachser · 3× · guard_or_tighten_branch · extra: frachtzuAbschlag
  - dachser · 1× · fix_both · missing: ?:MEHRKOSTEN GEM.VB MIT GÜLCIN CICEK · extra: abweichGewicht, mautDiff
  - dachser · 1× · fix_both · missing: ?:ZUSATZKOSTEN GEMÄSS ABSPRACHE MIT IHRER FR. GRAU. · extra: abweichGewicht
- `training.jsonl` — one JSON record per row; join to patterns via `row_uid`.
- `rule_spec.json` — the PHRASES catalog, per-forwarder thresholds, processor/resolver symbols, and an English glossary for every `inputs.*` key.

## Task

Propose a minimal patch to `assets/anmerkung.js` that closes the failure patterns, largest `count` first.

## Rules

1. The `engine_*` fields are authoritative: `engine_missing_phrase_keys` = phrases ground truth wants that the engine fails to emit (ADD a branch or LOOSEN its gate); `engine_extra_phrase_keys` = phrases the engine emits that truth rejects (GUARD or TIGHTEN the branch). Ignore the plain `predicted`/`missing_*`/`extra_*` fields unless `engine_label` is blank — they compare a possibly-stale tool output, not the current engine.
2. Diagnose gates from `summary.json` first: each pattern's `shared_inputs` are the cell values identical on EVERY failing row (prime gate signals); `varying_inputs` differ across rows and must not become gate conditions. Pull the matching `training.jsonl` records by `example_row_uids` for the full picture.
3. Emit phrases only via the existing `PHRASES` catalog and `join()` helper (it dedupes case-insensitively). New wording goes into `PHRASES` first; keys prefixed `lit_`/`tpl_`/`?:` are explained in `rule_spec.json`.
4. Respect each forwarder's `hasErr(value, threshold)` numeric guard and gate (see `rule_spec.forwarders.<fw>`). Do not weaken a gate so far that it would fire on rows the engine currently gets right (0 solved rows are the regression set).
5. Keep edits inside the `process<Forwarder>` functions (resolvers are already wired) unless a pattern clearly needs a new resolver column.

## Output format

For each pattern you fix, in priority order:
1. **Diagnosis** — which branch/gate is wrong and why, citing the `shared_inputs` evidence.
2. **Patch** — the exact code change (unified diff or before/after snippet).
3. **Coverage** — the `row_uid`s this change fixes, and any solved rows it could plausibly affect.

A fix is complete when re-running Train & Compare flips the row's `engine_matches_b` to `true` and empties its `engine_missing_phrase_keys` / `engine_extra_phrase_keys`.
